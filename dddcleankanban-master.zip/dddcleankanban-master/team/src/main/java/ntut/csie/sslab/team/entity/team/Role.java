package ntut.csie.sslab.team.entity.team;

public enum Role {
    CompanyAdmin, TeamAdmin, Member
}
