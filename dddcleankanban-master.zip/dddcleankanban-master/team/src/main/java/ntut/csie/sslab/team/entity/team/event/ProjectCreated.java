package ntut.csie.sslab.team.entity.team.event;

import ntut.csie.sslab.ddd.model.common.DateProvider;
import ntut.csie.sslab.ddd.model.DomainEvent;
import ntut.csie.sslab.team.entity.team.ProjectId;
import ntut.csie.sslab.team.entity.team.TeamId;

public class ProjectCreated extends DomainEvent {

    private final TeamId teamId;
    private final ProjectId projectId;
    private final String name;

    public ProjectCreated(TeamId teamId, ProjectId projectId, String name) {
        super(DateProvider.now());
        this.teamId = teamId;
        this.projectId = projectId;
        this.name = name;
    }

    public TeamId teamId() { return teamId; }

    public ProjectId projectId() {
        return projectId;
    }

    public String name() {
        return name;
    }
}
