package ntut.csie.sslab.team.entity.team.event;

import ntut.csie.sslab.ddd.model.common.DateProvider;
import ntut.csie.sslab.ddd.model.DomainEvent;
import ntut.csie.sslab.team.entity.team.ProjectId;
import ntut.csie.sslab.team.entity.team.TeamId;

public class ProjectRenamed extends DomainEvent {
    private final TeamId teamId;
    private final ProjectId projectId;
    private final String oldName;
    private final String newName;

    public ProjectRenamed(TeamId teamId, ProjectId projectId, String oldName, String newName) {
        super(DateProvider.now());
        this.teamId = teamId;
        this.projectId = projectId;
        this.oldName = oldName;
        this.newName = newName;
    }

    public TeamId teamId() {
        return teamId;
    }

    public ProjectId projectId() {
        return projectId;
    }

    public String oldName() {
        return oldName;
    }

    public String newName() {
        return newName;
    }
}
