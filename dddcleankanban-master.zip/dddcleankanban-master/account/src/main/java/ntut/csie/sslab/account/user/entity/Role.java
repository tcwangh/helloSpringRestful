package ntut.csie.sslab.account.user.entity;

public enum Role {
    Manager, User;
}
