package ntut.csie.sslab.account.user.usecase.get;

import ntut.csie.sslab.ddd.usecase.cqrs.Query;

public interface GetUserUseCase extends Query<GetUserInput, GetUserOutput> {
}
