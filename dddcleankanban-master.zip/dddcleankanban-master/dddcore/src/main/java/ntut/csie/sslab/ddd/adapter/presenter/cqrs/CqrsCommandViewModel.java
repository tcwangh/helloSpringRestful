package ntut.csie.sslab.ddd.adapter.presenter.cqrs;


import ntut.csie.sslab.ddd.adapter.presenter.CommonViewModel;

public class CqrsCommandViewModel extends CommonViewModel {
}
