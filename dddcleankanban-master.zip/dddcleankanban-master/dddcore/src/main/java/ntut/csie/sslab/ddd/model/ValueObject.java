package ntut.csie.sslab.ddd.model;

import java.io.Serializable;

public interface ValueObject extends Serializable {
}
