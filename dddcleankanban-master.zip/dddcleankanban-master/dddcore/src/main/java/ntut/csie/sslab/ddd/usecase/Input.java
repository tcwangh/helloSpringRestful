package ntut.csie.sslab.ddd.usecase;

public interface Input {

}
