package ntut.csie.sslab.kanban.board.usecase.port.in.getcontent;

public class CommittedWorkflowDto {
    private String boardId;
    private String workflowId;
    private int order;

    public String getBoardId() {
        return boardId;
    }

    public void setBoardId(String boardId) {
        this.boardId = boardId;
    }

    public String getWorkflowId() {
        return workflowId;
    }

    public void setWorkflowId(String workflowId) {
        this.workflowId = workflowId;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
}
