package ntut.csie.sslab.kanban.board.entity;

public enum BoardMemberType {
    Manager, Member
}
