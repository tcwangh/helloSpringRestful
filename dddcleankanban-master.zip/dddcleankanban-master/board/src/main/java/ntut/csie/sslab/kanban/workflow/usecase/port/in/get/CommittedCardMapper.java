package ntut.csie.sslab.kanban.workflow.usecase.port.in.get;

import ntut.csie.sslab.kanban.workflow.entity.CommittedCard;

public class CommittedCardMapper {
    public static CommittedCardDto toDto(CommittedCard committedCard){
        CommittedCardDto dto= new CommittedCardDto();
        dto.setCardId(committedCard.getCardId());
        dto.setLaneId(committedCard.getLaneId());
        dto.setOrder(committedCard.getOrder());
        return dto;
    }
}
