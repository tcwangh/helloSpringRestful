package ntut.csie.sslab.kanban.workflow.entity;

public enum LaneType {
    Standard, IceBox, Backlog, Archive
}
