package ntut.csie.sslab.kanban.workflow.entity;

public enum LaneLayout {
    Vertical,Horizontal
}
