package ntut.csie.sslab.kanban.card.entity;

public enum CardType {
    General, Expedite
}
